import { NavLink, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useNavItems } from '../lib/useNavItems'
import { useNavDisplay } from '../lib/navContext'
import NavIcon, { type NavIconEffect } from './NavIcon'

const EFFECTS: Record<string, NavIconEffect> = { '/': 'hop', '/library': 'books', '/plugins': 'plug', '/settings': 'spin', '/arcade': 'pad' }

/**
 * The four menu cards (Home · Library · Plugins · Settings) with a single
 * sliding active indicator that glides between cards like the AI-upscaler
 * selector. Icon visibility follows the nav-display mode (text/hybrid/icon).
 */
export default function NavMenuCards({ layoutId = 'nav-active' }: { layoutId?: string }) {
  const { navDisplay } = useNavDisplay()
  const { pathname } = useLocation()
  const items = useNavItems()

  const activeIndex = (() => {
    const match = items.find((i) => (i.end ? pathname === i.to : pathname.startsWith(i.to)))
    return match?.index ?? -1
  })()

  return (
    <div className="flex items-center gap-0.5">
      {items.map((item) => {
        const isActive = item.index === activeIndex
        const showIcon = navDisplay !== 'text'
        const showLabel = navDisplay !== 'icon'
        // Hybrid's label is a "when there's room" nicety, not load-bearing —
        // the icon alone is still a complete, recognizable menu item. Hiding
        // it below `xl` keeps 4 full labels + wordmark + socials + window
        // controls from ever needing more width than a normal window has,
        // instead of relying on clipping to save it after the fact.
        const labelResponsive = navDisplay === 'hybrid' ? 'hidden xl:inline' : ''
        const Icon = item.icon
        return (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            aria-current={isActive ? 'page' : undefined}
            className="group relative flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold text-[var(--text-dim)] transition-colors hover:text-[var(--text)]"
          >
            {isActive && (
              <motion.span
                layoutId={layoutId}
                className="absolute inset-0 rounded-xl bg-[var(--input-bg)] shadow-inner"
                transition={{ type: 'spring', stiffness: 500, damping: 34 }}
              />
            )}
            <span className="relative z-10 flex items-center gap-2">
              {showIcon && <NavIcon icon={Icon} effect={EFFECTS[item.to] ?? 'hop'} />}
              {showLabel && <span className={labelResponsive}>{item.label}</span>}
            </span>
          </NavLink>
        )
      })}
    </div>
  )
}