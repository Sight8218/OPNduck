import { useEffect, useRef, useState } from 'react'
import { Routes, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { ARCADE_ITEM, NAV_ITEMS, swipeFor } from '../lib/nav'

function indexOf(pathname: string): number {
  const match = [...NAV_ITEMS, ARCADE_ITEM].find((i) => (i.end ? pathname === i.to : pathname.startsWith(i.to)))
  return match?.index ?? 0
}

/**
 * Page swipe transition for the top-bar menu. The incoming page enters sliding
 * from the direction the menu moved and, when replaced, exits toward the
 * direction of travel. Speed adapts to menu distance, and the moving page gets
 * a soft blur that clears as it lands (a lightweight motion-blur feel).
 *
 * The previous menu index lives in a ref we write in an effect; reading it
 * during render is the standard framer transition idiom and is safe here.
 */
/**
 * One page's animated wrapper. `settled` is per instance so it starts false on every mount;
 * a shared flag reset in an effect would still be true for the first paint of the next page
 * and cancel its slide.
 */
function PageFrame({
  swipe,
  location,
  children,
}: {
  swipe: ReturnType<typeof swipeFor>
  location: ReturnType<typeof useLocation>
  children: React.ReactNode
}) {
  // The slide/fade is opacity + transform only: animating `filter: blur()` over a whole
  // page re-rasterizes it every frame and was the main cause of janky page switches.
  // Once the enter animation finishes the transform is reset to a literal `none`, because a
  // lingering transform on an ancestor breaks position: sticky/fixed descendants.
  const [settled, setSettled] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, x: swipe.direction * 40 }}
      animate={{
        opacity: 1,
        x: 0,
        transition: {
          duration: swipe.inDuration,
          ease: [0.22, 1, 0.36, 1],
        },
      }}
      exit={{
        opacity: 0,
        x: -swipe.direction * swipe.outDistance,
        transition: { duration: swipe.outDuration, ease: [0.22, 1, 0.36, 1] },
      }}
      onAnimationComplete={() => setSettled(true)}
      // Framer Motion keeps a real `transform` (e.g. translateX(0px)) applied
      // even when x has animated back to 0 — it never resets to a literal
      // `none`, since it's built for repeated GPU-accelerated animation.
      // Force it to a true `none` once settled; let Framer generate it
      // normally while the enter/exit animation is actually running.
      transformTemplate={(_, generated) => (settled ? 'none' : generated)}
    >
      {/* Routes normally always reflects the *live* current URL — even
          inside a motion.div that's still mid-exit-animation, since
          AnimatePresence only freezes this subtree's own props, not the
          router context. That caused a flash of the destination page
          (unanimated) before the old wrapper's exit had even started.
          Pinning `location` here freezes it to whatever was current when
          this motion.div was created, matching its key. */}
      <Routes location={location}>{children}</Routes>
    </motion.div>
  )
}

export default function PageTransition({ children }: { children: React.ReactNode }) {
  const location = useLocation()
  const { pathname } = location
  const next = indexOf(pathname)
  const prevRef = useRef(next)

  const swipe = swipeFor(prevRef.current, next)

  useEffect(() => {
    prevRef.current = next
  }, [next])

  return (
    <AnimatePresence mode="wait" initial={false}>
      <PageFrame key={pathname} swipe={swipe} location={location}>
        {children}
      </PageFrame>
    </AnimatePresence>
  )
}