import {
  IconDeviceGamepad2,
  IconHome2,
  IconLibrary,
  IconPlug,
  IconSettings,
  IconMenu2,
  type Icon,
} from '@tabler/icons-react'

/**
 * Navigation model shared by the top-bar menu, the hamburger menu, and the
 * swipe page transition. Each page has a fixed index so we can derive swipe
 * direction and speed from the distance between the previous and next menu.
 */

export interface NavItem {
  /** zero-based position in the menu, used for swipe direction/speed */
  index: number
  to: string
  label: string
  end: boolean
  /** Tabler outline icon for the menu card / hamburger link */
  icon: Icon
}

export const NAV_ITEMS: NavItem[] = [
  { index: 0, to: '/', label: 'Home', end: true, icon: IconHome2 },
  { index: 1, to: '/library', label: 'Library', end: false, icon: IconLibrary },
  { index: 2, to: '/plugins', label: 'Plugins', end: false, icon: IconPlug },
  { index: 3, to: '/settings', label: 'Settings', end: false, icon: IconSettings },
]

/** The secret Arcade page. Always routable; it only appears in the menu once pinned (see arcadeStore). */
export const ARCADE_ITEM: NavItem = { index: 4, to: '/arcade', label: 'Arcade', end: false, icon: IconDeviceGamepad2 }

export interface SocialItem {
  label: string
  url: string
  /** path (from public/) to the brand PNG provided by the user */
  icon: string
}

// Vite's `base: './'` (set for the packaged app, which loads over `file://`
// and can't resolve root-absolute paths) only rewrites paths it can see at
// build time — import statements and references inside index.html. These
// are plain runtime strings pointing at public/, so they need the same base
// prefix applied by hand via `import.meta.env.BASE_URL` ('/' in dev,
// './' in the built app) or they 404 under file://.
const ICON_BASE = `${import.meta.env.BASE_URL}icons/`

export const SOCIALS: SocialItem[] = [
  { label: 'Linktree', url: 'https://linktr.ee/DuckyDuckson', icon: `${ICON_BASE}linktree.png` },
  { label: 'X (Twitter)', url: 'https://x.com/Ducky_swe', icon: `${ICON_BASE}x.png` },
  { label: 'YouTube', url: 'https://www.youtube.com/@Ducky_Swe', icon: `${ICON_BASE}youtube.png` },
  { label: 'TikTok', url: 'https://www.tiktok.com/@mr.ducky.editz', icon: `${ICON_BASE}tiktok.png` },
  { label: 'GitHub', url: 'https://github.com/Sight8218', icon: `${ICON_BASE}github.png` },
  { label: 'Discord', url: 'https://discord.gg/B2uqWRNykm', icon: `${ICON_BASE}discord.png` },
]

/** Icon used for the hamburger menu toggle (classic three lines). */
export const HAMBURGER_ICON = IconMenu2

/**
 * Style of the menu cards' icon/text presentation.
 *  - text   = labels only (icons hidden)
 *  - hybrid = icon + label (default)
 *  - icon   = icons only
 */
export type NavDisplay = 'text' | 'hybrid' | 'icon'

const NAV_STORAGE_KEY = 'opnduck.navDisplay'

export function readNavDisplay(): NavDisplay {
  if (typeof window === 'undefined') return 'hybrid'
  try {
    const stored = localStorage.getItem(NAV_STORAGE_KEY)
    if (stored === 'text' || stored === 'hybrid' || stored === 'icon') return stored
  } catch {
    /* ignore */
  }
  return 'hybrid'
}

export function writeNavDisplay(mode: NavDisplay): void {
  try {
    localStorage.setItem(NAV_STORAGE_KEY, mode)
  } catch {
    /* ignore */
  }
}

/**
 * Transition config for a page swipe. `duration` shrinks as the menus get
 * further apart (adjacent moves stay deliberate, big jumps are fast) and the
 * page slides off/on in the direction of travel.
 */
export interface PageSwipe {
  direction: 1 | -1
  outDuration: number
  inDuration: number
  outDistance: number
}

export function swipeFor(current: number, next: number): PageSwipe {
  const distance = Math.abs(next - current)
  const base = 0.34 // seconds
  const duration = Math.max(0.14, base - distance * 0.05)
  return {
    direction: next < current ? -1 : 1,
    outDuration: duration,
    inDuration: Math.max(0.1, duration * 0.8),
    outDistance: 28 + distance * 16,
  }
}