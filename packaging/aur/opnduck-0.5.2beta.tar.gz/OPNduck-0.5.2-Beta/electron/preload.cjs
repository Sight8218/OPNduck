/*
 * OPNduck — local-first media processing suite.
 * Copyright (C) 2026 Aaron Jonsson
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

const { contextBridge, ipcRenderer, webUtils } = require('electron')

/** Safe, minimal bridge exposed to the renderer as `window.opnduckHost`. */
contextBridge.exposeInMainWorld('opnduckHost', {
  platformName: process.platform,
  isDesktop: true,
  window: {
    minimize: () => ipcRenderer.send('window:minimize'),
    maximize: () => ipcRenderer.send('window:maximize'),
    close: () => ipcRenderer.send('window:close'),
  },
  pickFile: (options) => ipcRenderer.invoke('dialog:pickFile', options ?? null),
  pickFiles: (options) => ipcRenderer.invoke('dialog:pickFiles', options ?? null),
  pickFolder: () => ipcRenderer.invoke('dialog:pickFolder'),
  // Dropped File objects carry no path in a sandboxed renderer; this resolves one.
  pathForFile: (file) => webUtils.getPathForFile(file),
  checkYtDlp: () => ipcRenderer.invoke('system:checkYtDlp'),
  installYtDlp: () => ipcRenderer.invoke('system:installYtDlp'),
  checkFfmpeg: () => ipcRenderer.invoke('system:checkFfmpeg'),
  checkDemucs: () => ipcRenderer.invoke('system:checkDemucs'),
  checkLibreOffice: () => ipcRenderer.invoke('system:checkLibreOffice'),
  checkRealesrgan: () => ipcRenderer.invoke('system:checkRealesrgan'),
  checkRife: () => ipcRenderer.invoke('system:checkRife'),
  checkFasterWhisper: () => ipcRenderer.invoke('system:checkFasterWhisper'),
  mcp: {
    info: () => ipcRenderer.invoke('mcp:info'),
    resetToken: () => ipcRenderer.invoke('mcp:resetToken'),
  },
  queue: {
    state: () => ipcRenderer.invoke('queue:state'),
    setPaused: (paused) => ipcRenderer.invoke('queue:setPaused', paused),
    onState: (listener) => {
      const handler = (_e, s) => listener(s)
      ipcRenderer.on('queue:state', handler)
      return () => ipcRenderer.removeListener('queue:state', handler)
    },
  },
  dev: {
    info: () => ipcRenderer.invoke('dev:info'),
    metrics: () => ipcRenderer.invoke('dev:metrics'),
    logs: () => ipcRenderer.invoke('dev:logs'),
    tasks: () => ipcRenderer.invoke('dev:tasks'),
    diagnostics: () => ipcRenderer.invoke('dev:diagnostics'),
    openUserData: () => ipcRenderer.invoke('dev:openUserData'),
    toggleDevTools: () => ipcRenderer.invoke('dev:toggleDevTools'),
    reloadUI: () => ipcRenderer.invoke('dev:reloadUI'),
    testNotification: () => ipcRenderer.invoke('dev:testNotification'),
    fakeJob: (fail) => ipcRenderer.invoke('dev:fakeJob', !!fail),
    clearEngineCache: () => ipcRenderer.invoke('dev:clearEngineCache'),
    ipc: () => ipcRenderer.invoke('dev:ipc'),
    settings: () => ipcRenderer.invoke('dev:settings'),
    showSettingsFile: () => ipcRenderer.invoke('dev:showSettingsFile'),
    jobChannels: () => ipcRenderer.invoke('dev:jobChannels'),
    startJob: (channel, req) => ipcRenderer.invoke('dev:startJob', channel, req),
    makeTestMedia: (kind) => ipcRenderer.invoke('dev:makeTestMedia', kind),
    loopLag: () => ipcRenderer.invoke('dev:loopLag'),
  },
  checkTorchEngine: () => ipcRenderer.invoke('system:checkTorchEngine'),
  probeMedia: (p) => ipcRenderer.invoke('media:probe', p),
  mediaFrame: (p, t, width) => ipcRenderer.invoke('media:frame', p, t, width),
  mediaThumbs: (p, duration, count) => ipcRenderer.invoke('media:thumbs', p, duration, count),
  installTool: (tool) => ipcRenderer.invoke('system:installTool', tool),
  cancelInstall: () => ipcRenderer.invoke('system:installCancel'),
  onInstallProgress: (listener) => {
    const handler = (_e, p) => listener(p)
    ipcRenderer.on('system:installProgress', handler)
    return () => ipcRenderer.removeListener('system:installProgress', handler)
  },
  settings: {
    get: () => ipcRenderer.invoke('settings:get'),
    set: (patch) => ipcRenderer.invoke('settings:set', patch),
  },
  subscriptions: {
    list: () => ipcRenderer.invoke('subs:list'),
    add: (input) => ipcRenderer.invoke('subs:add', input),
    remove: (id) => ipcRenderer.invoke('subs:remove', id),
    setEnabled: (id, enabled) => ipcRenderer.invoke('subs:setEnabled', id, enabled),
    checkNow: (id) => ipcRenderer.invoke('subs:checkNow', id),
    onChange: (listener) => {
      const handler = (_e, list) => listener(list)
      ipcRenderer.on('subs:changed', handler)
      return () => ipcRenderer.removeListener('subs:changed', handler)
    },
  },
  library: {
    exportHistory: () => ipcRenderer.invoke('library:export'),
    importHistory: () => ipcRenderer.invoke('library:import'),
    importApply: (entries, run) => ipcRenderer.invoke('library:importApply', entries, run),
  },
  login: {
    open: (url) => ipcRenderer.invoke('login:open', url),
    status: () => ipcRenderer.invoke('login:status'),
    clear: () => ipcRenderer.invoke('login:clear'),
    test: () => ipcRenderer.invoke('login:test'),
  },
  updates: {
    check: () => ipcRenderer.invoke('updates:check'),
    openRelease: (url) => ipcRenderer.invoke('updates:openRelease', url),
  },
  omarchy: {
    get: () => ipcRenderer.invoke('omarchy:get'),
    subscribe: (listener) => {
      const handler = (_e, theme) => listener(theme)
      ipcRenderer.on('omarchy:theme-changed', handler)
      return () => ipcRenderer.removeListener('omarchy:theme-changed', handler)
    },
  },
  tasks: {
    startDownload: (req) => ipcRenderer.invoke('tasks:start', req),
    startConvert: (req) => ipcRenderer.invoke('tasks:startConvert', req),
    startUpscale: (req) => ipcRenderer.invoke('tasks:startUpscale', req),
    startVideoUpscale: (req) => ipcRenderer.invoke('tasks:startVideoUpscale', req),
    startInterpolate: (req) => ipcRenderer.invoke('tasks:startInterpolate', req),
    startAudioAi: (req) => ipcRenderer.invoke('tasks:startAudioAi', req),
    startTrim: (req) => ipcRenderer.invoke('tasks:startTrim', req),
    startSubtitles: (req) => ipcRenderer.invoke('tasks:startSubtitles', req),
    cancel: (taskId) => ipcRenderer.send('tasks:cancel', taskId),
    rerun: (taskId, opts) => ipcRenderer.invoke('tasks:rerun', taskId, opts),
    openFolder: (taskId) => ipcRenderer.invoke('tasks:openFolder', taskId),
    clearFinished: () => ipcRenderer.invoke('tasks:clearFinished'),
    remove: (ids) => ipcRenderer.invoke('tasks:remove', ids),
    list: () => ipcRenderer.invoke('tasks:list'),
    runNext: (taskId) => ipcRenderer.invoke('tasks:runNext', taskId),
    logs: (taskId) => ipcRenderer.invoke('tasks:logs', taskId),
    watchLog: (taskId, on) => ipcRenderer.invoke('tasks:logWatch', taskId, on),
    onLog: (listener) => {
      const handler = (_e, payload) => listener(payload)
      ipcRenderer.on('tasks:log', handler)
      return () => ipcRenderer.removeListener('tasks:log', handler)
    },
    onUpdate: (listener) => {
      const handler = (_e, update) => listener(update)
      ipcRenderer.on('tasks:update', handler)
      return () => ipcRenderer.removeListener('tasks:update', handler)
    },
    getDefaultDownloadDir: () => ipcRenderer.invoke('tasks:defaultDownloadDir'),
    probe: (req) => ipcRenderer.invoke('tasks:probe', req),
  },
})